<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="eindopdracht2.css">
  </head>
  <body>
    <div class="center">
      <h1 class="hoofd">Memory</h1>
    </div>
    <div class="start">
      <button><a href="eindopdracht2.php"><h1 class="start">Start</h1></a></button>
    </div>

  </body>
</html>
